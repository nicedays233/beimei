package com.shenhan.nicedays;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NicedaysApplication {

    public static void main(String[] args) {
        SpringApplication.run(NicedaysApplication.class, args);
    }

}
